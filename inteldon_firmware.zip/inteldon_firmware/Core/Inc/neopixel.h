/*
 * neopixrel.h
 *
 *  Created on: Jun 3, 2025
 *      Author: haya-sense
 */

#ifndef INC_NEOPIXEL_H_
#define INC_NEOPIXEL_H_

# include <stdio.h>
#include <stdbool.h>
#include "main.h"

void  NeoPixInit (TIM_HandleTypeDef* _htim, uint32_t channel);
void  NeoPixStart (uint8_t* data, int len, bool wait);

#endif /* INC_NEOPIXEL_H_ */
